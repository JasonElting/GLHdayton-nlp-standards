def addquestion(list_of_q ,question):
  return list_of_q.append(question)