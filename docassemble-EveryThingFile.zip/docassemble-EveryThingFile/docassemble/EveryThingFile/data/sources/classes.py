from docassemble.base.legal import Court

class CourtInfo(Court):
   pass